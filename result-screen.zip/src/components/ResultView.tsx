"use client";

import { useRouter } from "next/navigation";
import ArcadeCard from "@/components/ArcadeCard";
import PixelButton from "@/components/PixelButton";
import { useQuiz } from "@/context/QuizProvider";
import type { Character } from "@/data/types";
import styles from "./ResultView.module.css";

type Props = {
  // Le personnage à afficher. null = pas de résultat disponible (état vide).
  character: Character | null;
  // Pas encore défini : on attend ta décision sur ce que fait SHARE.
  onShare?: () => void;
};

// Écran résultat (maquettes resultat.png / resultat_phone.png).
export default function ResultView({ character, onShare }: Props) {
  const router = useRouter();
  const { reset } = useQuiz();

  function playAgain() {
    reset(); // on efface les réponses puis retour à l'accueil
    router.push("/");
  }

  if (!character) {
    return (
      <ArcadeCard width={584} className={`${styles.result} ${styles.empty}`}>
        <h1 className={styles.you}>No result yet</h1>
        <p className={styles.description}>
          We could not load your legend. Take the quiz again to meet your
          match.
        </p>
        <div className={styles.buttons}>
          <PixelButton className={styles.btn} onClick={playAgain}>
            PLAY AGAIN
          </PixelButton>
        </div>
      </ArcadeCard>
    );
  }

  return (
    <ArcadeCard width={584} className={styles.result}>
      <p className={styles.you}>You are…</p>

      <div className={styles.frame}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          className={styles.image}
          src={`/images/characters/${encodeURIComponent(character.image)}`}
          alt={character.name}
        />
      </div>

      <h1 className={styles.title}>{character.uniqueTitle}</h1>
      <p className={styles.meta}>
        {character.game} · {character.publisher} · {character.year}
      </p>
      <p className={styles.description}>{character.description}</p>

      <p className={styles.pill}>
        SIGNATURE ABILITY: {character.signatureAbility}
      </p>

      <div className={styles.buttons}>
        <PixelButton className={styles.btn} onClick={onShare}>
          SHARE
        </PixelButton>
        <PixelButton
          variant="outline"
          className={styles.btn}
          onClick={playAgain}
        >
          PLAY AGAIN
        </PixelButton>
      </div>
    </ArcadeCard>
  );
}
